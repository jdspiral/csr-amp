// app/dashboard/page.tsx
export const revalidate = 60; // Adjust as needed

export default function DashboardPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Dashboard Overview</h2>
      <p className="mb-6">
        Placeholder for analytics and system status. Extend with charts, reports, or user statistics.
      </p>
      <a href="/users" className="text-blue-600 hover:underline">
        View Users
      </a>
    </div>
  );
}
