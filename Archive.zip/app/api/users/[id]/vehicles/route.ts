import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function GET(
  _req: Request,
  context: { params: { id: string } }
) {
  const { id } = await context.params;

  const { data, error } = await supabase
    .from('vehicles')
    .select('*') // ✅ select all fields
    .eq('user_id', id); // ✅ all vehicles for this user

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { user_id, license_plate, make, model, year } = body;

    const { data, error } = await supabase
      .from('vehicles')
      .insert([{ user_id, license_plate, make, model, year }])
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json(data);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
