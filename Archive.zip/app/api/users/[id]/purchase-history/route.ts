// app/api/users/[id]/purchase-history/route.ts
import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function GET(
  _req: Request,
  context: { params: { id: string } }
) {
  // Await params because of Next.js 14/15 dynamic routing
  const { id } = await context.params;

  // Query purchase history along with linked vehicle and subscription details.
  const { data, error } = await supabase
    .from('purchase_history')
    .select(`
       id,
       purchase_date,
       amount,
       description,
       vehicle:vehicle_id (
         id, make, model, license_plate
       ),
       subscription:subscription_id (
         id, plan, status
       )
    `)
    .eq('user_id', id)
    .order('purchase_date', { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data);
}
