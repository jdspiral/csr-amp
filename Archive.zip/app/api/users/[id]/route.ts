// app/api/users/[id]/route.ts
import { supabase } from '@/lib/supabase';
import { NextRequest, NextResponse } from 'next/server';

// GET: Fetch a single user by ID
export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  // Wait for the context to resolve the route parameters
  const { params } = await context;
  const { id } = await params;

  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error || !data) {
    return NextResponse.json({ error: error?.message || 'User not found' }, { status: 404 });
  }

  return NextResponse.json(data);
}

export async function PUT(
  req: Request,
  context: { params: Promise<{ id: string }> }
) {
  const { params } = await context;
  const { id } = await params;

  const body = await req.json();

  // ✅ Validation logic
  if (body.status === 'active') {
    const { data: userVehicles } = await supabase
      .from('vehicles')
      .select('id')
      .eq('user_id', id);

    const vehicleIds = userVehicles?.map((v) => v.id) ?? [];

    const { count } = await supabase
      .from('subscriptions')
      .select('id', { count: 'exact', head: true })
      .in('vehicle_id', vehicleIds)
      .eq('status', 'active');

    if (!count || count === 0) {
      return NextResponse.json(
        { error: 'Active users must have an active subscription' },
        { status: 400 }
      );
    }
  }

  const { data, error } = await supabase
    .from('users')
    .update({ ...body, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();

  if (error || !data) {
    return NextResponse.json({ error: error?.message || 'Failed to update user' }, { status: 400 });
  }

  return NextResponse.json(data);
}



// DELETE: "Cancel" a user account by performing a soft delete (update status)
export async function DELETE(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { params } = await context;
  const { id } = await params;

  const { data, error } = await supabase
    .from('users')
    .update({ status: 'canceled', updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}
