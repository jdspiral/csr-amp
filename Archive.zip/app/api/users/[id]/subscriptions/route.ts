import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function GET(
  _req: Request,
  context: { params: { id: string } }
) {
  const { id } = await context.params;

  const { data, error } = await supabase
    .from('subscriptions')
    .select('*, vehicle:vehicle_id(*)') // fetch vehicle info via foreign key
    .eq('user_id', id)
    .order('created_at', { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}

export async function POST(req: Request) {
  const body = await req.json();
  const { vehicle_id, status, plan, start_date } = body;

  const { data, error } = await supabase
    .from('subscriptions')
    .insert([
      {
        vehicle_id,
        status,
        plan,
        start_date,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
    .select()
    .maybeSingle();

  if (error || !data) {
    return NextResponse.json({ error: error?.message || 'Failed to create subscription' }, { status: 400 });
  }

  return NextResponse.json(data);
}
