// app/api/purchase-history/route.ts
import { NextResponse } from 'next/server';
import type { PurchaseHistory } from '@/interfaces';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    // Expecting: user_id, purchase_date, amount, description, subscriptionPlan, and optionally vehicle_id.
    const { user_id, purchase_date, amount, description, subscriptionPlan, vehicle_id } = body;
    
    if (!user_id || !purchase_date || !amount || !description) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }
    
    // Create a new purchase history record.
    const newRecord: PurchaseHistory = {
      id: crypto.randomUUID(),
      user_id,
      purchase_date,
      amount,
      description,
      subscriptionPlan: subscriptionPlan || '',
      vehicle: undefined, // If you have vehicle details, you can update this.
    };

    // In a real app, store newRecord in the database here.
    return NextResponse.json(newRecord, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create purchase history record' }, { status: 500 });
  }
}
