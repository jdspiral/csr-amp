// app/api/subscriptions/[id]/route.ts
import { Subscription } from '@/interfaces';
import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  const id = (await params).id;
  try {
    const body = await request.json();
    const { data, error } = await supabase
      .from('subscriptions')
      .update(body)
      .eq('id', id);
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json(data);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}


export async function POST(request: Request) {
    try {
      const body = await request.json();
      // Expecting: user_id, vehicle_id, plan, start_date, status
      const { user_id, vehicle_id, plan, start_date, status } = body;
      if (!user_id || !vehicle_id || !plan || !start_date || !status) {
        return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
      }
      // Replace this pseudo-code with your actual database insertion.
      const newSubscription: Subscription = {
        id: crypto.randomUUID(),
        user_id,
        vehicle_id,
        plan,
        start_date,
        status,
        vehicle: null,
      };
  
      return NextResponse.json(newSubscription, { status: 201 });
    } catch (error) {
      console.error(error);
      return NextResponse.json({ error: 'Failed to create subscription' }, { status: 500 });
    }
  }
