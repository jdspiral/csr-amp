// app/api/subscriptions/[id]/route.ts
import { Subscription } from '@/interfaces';
import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

// export async function PUT(
//   request: Request,
//   context: { params: { id: string } }
// ) {
//   const id = (await context.params).id;
//   try {
//     const body = await request.json();
//     const { data, error } = await supabase
//       .from('subscriptions')
//       .update(body)
//       .eq('id', id);
//     if (error) {
//       return NextResponse.json({ error: error.message }, { status: 500 });
//     }
//     return NextResponse.json(data);
//   } catch (err: any) {
//     return NextResponse.json({ error: err.message }, { status: 500 });
//   }
// }

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    // Replace with your database deletion logic.
    return NextResponse.json({ message: `Subscription ${id} deleted` }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete subscription' }, { status: 500 });
  }
}

// Optionally, include PUT to update a subscription.
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const body = await request.json();
    // Example update logic.
    const updatedSubscription: Subscription = {
      id,
      user_id: body.user_id,
      vehicle_id: body.vehicle_id,
      plan: body.plan,
      start_date: body.start_date,
      status: body.status,
      vehicle: null,
    };
    return NextResponse.json(updatedSubscription, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update subscription' }, { status: 500 });
  }
}

export async function POST(req: Request) {
    const body = await req.json();
    const { user_id, vehicle_id, plan, start_date, status } = body;
  
    // ✅ Check if user already has a non-canceled subscription
    const { data: existing, error: existingError } = await supabase
      .from('subscriptions')
      .select('id')
      .eq('user_id', user_id)
      .in('status', ['active', 'paused', 'overdue']) // only block if active-ish
      .maybeSingle();
  
    if (existing) {
      return NextResponse.json(
        { error: 'User already has a subscription' },
        { status: 400 }
      );
    }
  
    // ✅ Create new subscription
    const { data, error } = await supabase.from('subscriptions').insert([
      {
        user_id,
        vehicle_id,
        plan,
        start_date,
        status,
      },
    ]).select().single();
  
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
  
    return NextResponse.json(data);
  }

  export async function GET(request: Request, { params }: { params: { id: string } }) {
    try {
      const { id: userId } = params;
      // Replace this dummy data with your database query.
      const subscriptions: Subscription[] = [
        {
          id: 'sub-1',
          user_id: userId,
          vehicle_id: 'vehicle-1',
          plan: 'Basic',
          start_date: new Date().toISOString(),
          status: 'active',
          vehicle: {
            id: 'vehicle-1',
            user_id: userId,
            license_plate: 'ABC123',
            make: 'Toyota',
            model: 'Corolla',
            year: 2020,
          },
        },
      ];
      return NextResponse.json(subscriptions, { status: 200 });
    } catch (error) {
      console.error(error);
      return NextResponse.json({ error: 'Failed to fetch subscriptions' }, { status: 500 });
    }
  }
