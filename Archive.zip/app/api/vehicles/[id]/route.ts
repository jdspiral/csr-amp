// app/api/vehicles/[id]/route.ts
import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function PUT(
    req: Request,
    { params }: { params: { id: string } }
  ) {
    const { id } = params;
    const body = await req.json();
  
    const { data, error } = await supabase
      .from('vehicles')
      .update({ ...body, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
  
    if (error || !data) {
      return NextResponse.json({ error: error?.message || 'Failed to update vehicle' }, { status: 400 });
    }
  
    return NextResponse.json(data);
  }

  
export async function DELETE(
  _request: Request,
  context: { params: { id: string } }
) {
  const id = (await context.params).id;
  const { data, error } = await supabase
    .from('vehicles')
    .delete()
    .eq('id', id)
    .select().single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data);
}
