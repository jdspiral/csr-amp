// app/api/vehicles/route.ts
import { supabase } from '@/lib/supabase';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const body = await req.json();

  const { user_id, license_plate, make, model, year } = body;

  const { data, error } = await supabase
    .from('vehicles')
    .insert([{ user_id, license_plate, make, model, year }])
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}