// app/users/page.tsx
import { getUsers } from '@/lib/api';
import UserList from '@/components/UserList';

export const revalidate = 60; // You can adjust or remove revalidation if using SSR

export default async function UsersPage() {
  // Fetch initial data on the server (page 1)
  const initialUsers = await getUsers(1, 10);
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">User Management</h1>
      <UserList initialData={initialUsers} />
    </div>
  );
}
