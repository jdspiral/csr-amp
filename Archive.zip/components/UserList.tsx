// components/UserList.tsx
'use client';

import { useEffect, useState, ChangeEvent } from 'react';
import Link from 'next/link';
import type { User } from '@/interfaces';
import { getUsers } from '@/lib/api';

interface UserListProps {
  initialData: { data: User[]; page: number; limit: number };
}

export default function UserList({ initialData }: UserListProps) {
  const [users, setUsers] = useState<User[]>(initialData.data);
  const [page, setPage] = useState<number>(initialData.page);
  const [limit] = useState<number>(initialData.limit);
  const [search, setSearch] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  async function fetchUsers(newPage: number, newSearch: string = search) {
    setLoading(true);
    try {
      const result = await getUsers(newPage, limit);
      setUsers(result.data);
      setPage(result.page);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  function handleSearch(e: ChangeEvent<HTMLInputElement>) {
    const value = e.target.value;
    setSearch(value);
    fetchUsers(1, value);
  }

  return (
    <div>
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search by name..."
          value={search}
          onChange={handleSearch}
          className="p-2 border border-gray-300 rounded w-full"
        />
      </div>
      {loading ? (
        <p>Loading users...</p>
      ) : (
        <table className="w-full border border-gray-200">
          <thead className="bg-gray-800">
            <tr>
              <th className="p-2 border">Name</th>
              <th className="p-2 border">Email</th>
              <th className="p-2 border">Phone</th>
              <th className="p-2 border">Status</th>
              <th className="p-2 border">Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-gray-700">
                <td className="p-2 border">{u.name}</td>
                <td className="p-2 border">{u.email}</td>
                <td className="p-2 border">{u.phone || 'N/A'}</td>
                <td className="p-2 border">
                  {u.status === 'canceled' ? (
                    <span className="text-red-600 font-bold">Canceled</span>
                  ) : (
                    <span className="text-green-600">Active</span>
                  )}
                </td>
                <td className="p-2 border">
                  <Link href={`/users/${u.id}`} className="text-blue-600 hover:underline">
                    View/Edit
                  </Link>
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr>
                <td colSpan={6} className="p-4 text-center">
                  No users found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
      <div className="mt-4 flex justify-center items-center gap-4">
        <button
          onClick={() => fetchUsers(Math.max(page - 1, 1))}
          disabled={page === 1}
          className="px-3 py-1 bg-gray-800 rounded disabled:bg-gray-600"
        >
          Prev
        </button>
        <span>Page {page}</span>
        <button
          onClick={() => fetchUsers(page + 1)}
          disabled={users.length < limit}
          className="px-3 py-1 bg-gray-800 rounded disabled:bg-gray-600"
        >
          Next
        </button>
      </div>
    </div>
  );
}
