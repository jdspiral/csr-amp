'use client';
import { useState } from 'react';
import type { Vehicle } from '@/interfaces';

interface VehicleListProps {
  vehicles: Vehicle[];
  refreshVehicles: () => Promise<void>;
}

export default function VehicleList({ vehicles, refreshVehicles }: VehicleListProps) {
  // Local state for editing: store an id of the vehicle being edited and its form values.
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({
    license_plate: '',
    make: '',
    model: '',
    year: '',
  });
  const [newVehicle, setNewVehicle] = useState({
    license_plate: '',
    make: '',
    model: '',
    year: '',
  });
  const [adding, setAdding] = useState(false);

  // Handler to start editing a vehicle.
  const handleEditClick = (vehicle: Vehicle) => {
    setEditingId(vehicle.id);
    setEditForm({
      license_plate: vehicle.license_plate,
      make: vehicle.make || '',
      model: vehicle.model || '',
      year: vehicle.year ? vehicle.year.toString() : '',
    });
  };

  // Handle cancel editing.
  const handleCancelEdit = () => {
    setEditingId(null);
    setEditForm({ license_plate: '', make: '', model: '', year: '' });
  };

  // Save updates for an edited vehicle.
  const handleSaveEdit = async (id: string) => {
    try {
      const res = await fetch(`/api/vehicles/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...editForm,
          year: parseInt(editForm.year),
        }),
      });
      if (res.ok) await refreshVehicles();
      setEditingId(null);
    } catch (err) {
      console.error('Error updating vehicle:', err);
    }
  };

  // Delete a vehicle.
  // const handleDelete = async (id: string) => {
  //   try {
  //     const res = await fetch(`/api/vehicles/${id}`, {
  //       method: 'DELETE',
  //     });
  //     if (res.ok) await refreshVehicles();
  //   } catch (err) {
  //     console.error('Error deleting vehicle:', err);
  //   }
  // };

  // Handle adding new vehicle.
  // const handleAddVehicle = async () => {
  //   setAdding(true);
  //   try {
  //     const res = await fetch('/api/vehicles', {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' },
  //       body: JSON.stringify({
  //         ...newVehicle,
  //         year: parseInt(newVehicle.year),
  //       }),
  //     });
  //     if (res.ok) {
  //       setNewVehicle({ license_plate: '', make: '', model: '', year: '' });
  //       await refreshVehicles();
  //     } else {
  //       console.error('Error adding vehicle:', await res.text());
  //     }
  //   } catch (err) {
  //     console.error('Vehicle add error:', err);
  //   } finally {
  //     setAdding(false);
  //   }
  // };

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Vehicles</h3>
      <table className="w-full border-collapse">
        <thead className="bg-gray-800">
          <tr>
            <th className="p-2 border">License Plate</th>
            <th className="p-2 border">Make</th>
            <th className="p-2 border">Model</th>
            <th className="p-2 border">Year</th>
            <th className="p-2 border">Actions</th>
          </tr>
        </thead>
        <tbody>
          {vehicles.map((vehicle) => (
            <tr key={vehicle.id} className="hover:bg-gray-700">
              <td className="p-2 border">
                {editingId === vehicle.id ? (
                  <input
                    type="text"
                    value={editForm.license_plate}
                    onChange={(e) =>
                      setEditForm((prev) => ({ ...prev, license_plate: e.target.value }))
                    }
                    className="p-1 border rounded"
                  />
                ) : (
                  vehicle.license_plate
                )}
              </td>
              <td className="p-2 border">
                {editingId === vehicle.id ? (
                  <input
                    type="text"
                    value={editForm.make}
                    onChange={(e) =>
                      setEditForm((prev) => ({ ...prev, make: e.target.value }))
                    }
                    className="p-1 border rounded"
                  />
                ) : (
                  vehicle.make
                )}
              </td>
              <td className="p-2 border">
                {editingId === vehicle.id ? (
                  <input
                    type="text"
                    value={editForm.model}
                    onChange={(e) =>
                      setEditForm((prev) => ({ ...prev, model: e.target.value }))
                    }
                    className="p-1 border rounded"
                  />
                ) : (
                  vehicle.model
                )}
              </td>
              <td className="p-2 border">
                {editingId === vehicle.id ? (
                  <input
                    type="number"
                    value={editForm.year}
                    onChange={(e) =>
                      setEditForm((prev) => ({ ...prev, year: e.target.value }))
                    }
                    className="p-1 border rounded"
                  />
                ) : (
                  vehicle.year
                )}
              </td>
              <td className="p-2 border">
                {editingId === vehicle.id ? (
                  <>
                    <button
                      onClick={() => handleSaveEdit(vehicle.id)}
                      className="bg-green-600 text-white px-2 py-1 rounded mr-2"
                    >
                      Save
                    </button>
                    <button
                      onClick={handleCancelEdit}
                      className="bg-gray-600 text-white px-2 py-1 rounded"
                    >
                      Cancel
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => handleEditClick(vehicle)}
                      className="bg-blue-600 text-white px-2 py-1 rounded mr-2"
                    >
                      Edit
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
          {/* Row for adding a new vehicle */}
          <tr>
            <td className="p-2 border">
              <input
                type="text"
                placeholder="License Plate"
                value={newVehicle.license_plate}
                onChange={(e) =>
                  setNewVehicle((prev) => ({ ...prev, license_plate: e.target.value }))
                }
                className="p-1 border rounded"
              />
            </td>
            <td className="p-2 border">
              <input
                type="text"
                placeholder="Make"
                value={newVehicle.make}
                onChange={(e) =>
                  setNewVehicle((prev) => ({ ...prev, make: e.target.value }))
                }
                className="p-1 border rounded"
              />
            </td>
            <td className="p-2 border">
              <input
                type="text"
                placeholder="Model"
                value={newVehicle.model}
                onChange={(e) =>
                  setNewVehicle((prev) => ({ ...prev, model: e.target.value }))
                }
                className="p-1 border rounded"
              />
            </td>
            <td className="p-2 border">
              <input
                type="number"
                placeholder="Year"
                value={newVehicle.year}
                onChange={(e) =>
                  setNewVehicle((prev) => ({ ...prev, year: e.target.value }))
                }
                className="p-1 border rounded"
              />
            </td>
            {/* <td className="p-2 border">
              <button
                onClick={handleAddVehicle}
                disabled={adding}
                className="bg-blue-600 text-white px-2 py-1 rounded"
              >
                {adding ? 'Adding...' : 'Add'}
              </button>
            </td> */}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
