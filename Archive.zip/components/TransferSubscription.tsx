// components/TransferSubscription.tsx
'use client';

import { useState } from 'react';
import type { Subscription, Vehicle } from '@/interfaces';
import { updateSubscription } from '@/lib/api';

interface TransferSubscriptionProps {
  subscription: Subscription;
  vehicles: Vehicle[]; // List of vehicles the user owns
  onTransfer: () => void; // Callback to refresh subscriptions after transfer
}

export default function TransferSubscription({ subscription, vehicles, onTransfer }: TransferSubscriptionProps) {
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(subscription.vehicle_id || '');
  const [transferring, setTransferring] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  async function handleTransfer() {
    setTransferring(true);
    setError('');
    try {
      if (selectedVehicleId === subscription.vehicle_id) {
        setError('Please select a different vehicle for transfer.');
        return;
      }
      // Call the API to update the subscription's vehicle_id
      await updateSubscription(subscription.id, { vehicle_id: selectedVehicleId });
      onTransfer();
    } catch (err: any) {
      setError(err.message || 'Transfer failed');
    } finally {
      setTransferring(false);
    }
  }

  return (
    <div className="border p-2 rounded mt-4">
      <h4 className="font-semibold mb-2">Transfer Subscription</h4>
      {error && <p className="text-red-600 mb-2">{error}</p>}
      <label className="block mb-2">
        Select New Vehicle:
        <select
          value={selectedVehicleId}
          onChange={(e) => setSelectedVehicleId(e.target.value)}
          className="ml-2 p-2 border rounded"
        >
          <option value="">Select a vehicle</option>
          {vehicles.map((vehicle) => (
            <option key={vehicle.id} value={vehicle.id}>
              {vehicle.make} {vehicle.model} ({vehicle.license_plate})
            </option>
          ))}
        </select>
      </label>
      <button
        onClick={handleTransfer}
        disabled={transferring || !selectedVehicleId}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        {transferring ? 'Transferring...' : 'Confirm Transfer'}
      </button>
    </div>
  );
}
