'use client';
import { useState, useEffect } from 'react';
import type { Subscription, Vehicle } from '@/interfaces';
import {
  getSubscriptionsByUser,
  createSubscription,
  deleteSubscription,
} from '@/lib/api';

interface SubscriptionListProps {
  userId: string;
  vehicles: Vehicle[]; // List of vehicles available to assign to a subscription
  refreshVehicles: () => Promise<void>;
}

export default function SubscriptionList({
  userId,
  vehicles,
  refreshVehicles,
}: SubscriptionListProps) {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [plan, setPlan] = useState('');
  const [vehicleId, setVehicleId] = useState('');
  const [status, setStatus] = useState('active');
  const [message, setMessage] = useState('');

  async function fetchSubscriptions() {
    try {
      const subs = await getSubscriptionsByUser(userId);
      setSubscriptions(subs);
    } catch (err) {
      console.error('Error fetching subscriptions:', err);
    }
  }

  useEffect(() => {
    fetchSubscriptions();
  }, [userId]);

  async function handleAddSubscription(e: React.FormEvent) {
    e.preventDefault();
    if (!vehicleId || !plan) {
      setMessage('Please select a plan and vehicle.');
      return;
    }
    try {
      await createSubscription({
        user_id: userId,
        vehicle_id: vehicleId,
        plan,
        start_date: new Date().toISOString(),
        status,
      });
      setPlan('');
      setVehicleId('');
      await fetchSubscriptions();
    } catch (err) {
      setMessage('Error adding subscription');
    }
  }

  async function handleDelete(subscriptionId: string) {
    try {
      await deleteSubscription(subscriptionId);
      await fetchSubscriptions();
    } catch (err) {
      setMessage('Error deleting subscription');
    }
  }

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Subscriptions</h3>
      {message && <p className="text-red-600">{message}</p>}
      <form onSubmit={handleAddSubscription} className="mb-4">
        <select
          value={plan}
          onChange={(e) => setPlan(e.target.value)}
          className="border p-2 rounded mr-2"
        >
          <option value="">Select Plan</option>
          <option value="Basic">Basic</option>
          <option value="Premium">Premium</option>
          <option value="Premium">Unlimited</option>
        </select>
        <select
          value={vehicleId}
          onChange={(e) => setVehicleId(e.target.value)}
          className="border p-2 rounded mr-2"
        >
          <option value="">Select Vehicle</option>
          {vehicles.map((v) => (
            <option key={v.id} value={v.id}>
              {v.make} {v.model} ({v.license_plate})
            </option>
          ))}
        </select>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Add Subscription
        </button>
      </form>
      <table className="w-full border-collapse">
        <thead className="bg-gray-800">
          <tr>
            <th className="p-2 border">Plan</th>
            <th className="p-2 border">Status</th>
            <th className="p-2 border">Start Date</th>
            <th className="p-2 border">Vehicle</th>
            <th className="p-2 border">Actions</th>
          </tr>
        </thead>
        <tbody>
          {subscriptions.map((sub) => (
            <tr key={sub.id} className="hover:bg-gray-700">
              <td className="p-2 border">{sub.plan}</td>
              <td className="p-2 border">{sub.status}</td>
              <td className="p-2 border">
                {new Date(sub.start_date).toLocaleDateString()}
              </td>
              <td className="p-2 border">
                {sub.vehicle
                  ? `${sub.vehicle.make} ${sub.vehicle.model} (${sub.vehicle.license_plate})`
                  : 'N/A'}
              </td>
              <td className="p-2 border">
                <button
                  onClick={() => handleDelete(sub.id)}
                  className="bg-red-600 text-white px-2 py-1 rounded"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
