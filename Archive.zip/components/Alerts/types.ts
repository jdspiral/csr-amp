interface WarningAlertProps {
    children?: React.ReactNode;
  }