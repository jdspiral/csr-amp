// lib/api.ts
import type { PurchaseHistory, Subscription, User, Vehicle } from '@/interfaces';

// Helper to resolve absolute URL on the server
const getBaseUrl = () => {
  // Use environment variable or fallback to localhost
  return process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
};

const baseUrl = typeof window === 'undefined' ? getBaseUrl() : '';

// Fetch a list of users with pagination
export async function getUsers(page: number = 1, limit: number = 10): Promise<{ data: User[]; page: number; limit: number }> {
  const res = await fetch(`${baseUrl}/api/users?page=${page}&limit=${limit}`, { cache: 'no-store' });
  if (!res.ok) {
    throw new Error('Error fetching users');
  }
  return res.json();
}

// Fetch a single user by ID
export async function getUser(id: string): Promise<User> {
  const res = await fetch(`${baseUrl}/api/users/${id}`, { cache: 'no-store' });
  if (!res.ok) {
    throw new Error('Error fetching user');
  }
  return res.json();
}

// Update a user by ID
// export async function updateUser(
//   id: string,
//   updateData: Partial<User>
// ): Promise<User> {
//   const res = await fetch(`${baseUrl}/api/users/${id}`, {
//     method: 'PUT',
//     headers: {
//       'Content-Type': 'application/json'
//     },
//     body: JSON.stringify(updateData)
//   });
//   if (!res.ok) {
//     throw new Error('Error updating user');
//   }
//   return res.json();
// }

// Delete a user by ID
export async function deleteUser(id: string): Promise<User> {
  const res = await fetch(`${baseUrl}/api/users/${id}`, {
    method: 'DELETE'
  });
  if (!res.ok) {
    throw new Error('Error deleting user');
  }
  return res.json();
}

// Update a subscription by ID
// export async function updateSubscription(
//     id: string,
//     updateData: Partial<Subscription>
//   ): Promise<Subscription> {
//     const res = await fetch(`${baseUrl}/api/subscriptions/${id}`, {
//       method: 'PUT',
//       headers: {
//         'Content-Type': 'application/json'
//       },
//       body: JSON.stringify(updateData)
//     });
//     if (!res.ok) {
//       throw new Error('Error updating subscription');
//     }
//     return res.json();
//   }

  export async function updateVehicle(
    id: string,
    updateData: Partial<Vehicle>
  ): Promise<Vehicle> {
    const res = await fetch(`${baseUrl}/api/vehicles/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updateData)
    });
  
    if (!res.ok) throw new Error('Error updating vehicle');
    return res.json();
  }

//   export async function createSubscription(sub: {
//     user_id: string;
//     vehicle_id: string;
//     plan: string;
//     start_date: string;
//     status: string;
//   }) {
//     const res = await fetch(`${baseUrl}/api/subscriptions`, {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify(sub),
//     });
  
//     if (!res.ok) throw new Error('Error creating subscription');
//     return res.json();
//   }

//   export async function createVehicle(vehicle: {
//     user_id: string;
//     license_plate: string;
//     make: string;
//     model: string;
//     year: number;
//   }) {
//     const res = await fetch(`${baseUrl}/api/vehicles`, {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify(vehicle),
//     });
  
//     if (!res.ok) throw new Error('Error creating vehicle');
//     return res.json();
//   }

  /**
 * Fetch a user's details.
 */
// export async function getUser(userId: string): Promise<User> {
//     const res = await fetch(`/api/users/${userId}`);
//     if (!res.ok) {
//       throw new Error(`Failed to fetch user with id ${userId}`);
//     }
//     return res.json();
//   }
  
  /**
   * Update a user's data.
   * @param userId - The ID of the user.
   * @param data - Partial user data to update.
   */
  export async function updateUser(
    userId: string,
    data: Partial<User> | Record<string, any>
  ): Promise<User> {
    const res = await fetch(`/api/users/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      throw new Error(`Failed to update user with id ${userId}`);
    }
    return res.json();
  }
  
  /**
   * Get all vehicles for a user.
   */
  export async function getVehicles(userId: string): Promise<Vehicle[]> {
    const res = await fetch(`/api/users/${userId}/vehicles`);
    if (!res.ok) {
      throw new Error(`Failed to fetch vehicles for user ${userId}`);
    }
    return res.json();
  }
  
  /**
   * Get all subscriptions for a user.
   */
  export async function getSubscriptions(userId: string): Promise<Subscription[]> {
    const res = await fetch(`/api/users/${userId}/subscriptions`);
    if (!res.ok) {
      throw new Error(`Failed to fetch subscriptions for user ${userId}`);
    }
    return res.json();
  }
  
  /**
   * Get a user's purchase history.
   */
  export async function getPurchaseHistory(userId: string): Promise<PurchaseHistory[]> {
    const res = await fetch(`/api/users/${userId}/purchase-history`);
    if (!res.ok) {
      throw new Error(`Failed to fetch purchase history for user ${userId}`);
    }
    return res.json();
  }
  
  /**
   * Create a new vehicle.
   * @param data - Vehicle data including a user_id field.
   */
  export async function createVehicle(data: {
    user_id: string;
    license_plate: string;
    make: string;
    model: string;
    year: number;
  }): Promise<Vehicle> {
    const res = await fetch(`/api/vehicles`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      throw new Error('Failed to create vehicle');
    }
    return res.json();
  }

  // lib/api.ts

// --- Existing user/vehicle functions (e.g. getUser, updateUser, getVehicles, etc.) ---

/**
 * Create a new subscription.
 */
export async function createSubscription(data: {
  user_id: string;
  vehicle_id: string;
  plan: string;
  start_date: string;
  status: string;
}): Promise<Subscription> {
  const res = await fetch(`/api/subscriptions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    throw new Error('Failed to create subscription');
  }
  return res.json();
}

/**
 * Delete a subscription by ID.
 */
export async function deleteSubscription(subscriptionId: string): Promise<{ message: string }> {
  const res = await fetch(`/api/subscriptions/${subscriptionId}`, {
    method: 'DELETE',
  });
  if (!res.ok) {
    throw new Error('Failed to delete subscription');
  }
  return res.json();
}

/**
 * Update a subscription by ID.
 */
export async function updateSubscription(
  subscriptionId: string,
  data: Partial<Subscription>
): Promise<Subscription> {
  const res = await fetch(`/api/subscriptions/${subscriptionId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    throw new Error('Failed to update subscription');
  }
  return res.json();
}

/**
 * Get subscriptions for a specific user.
 */
export async function getSubscriptionsByUser(userId: string): Promise<Subscription[]> {
  const res = await fetch(`/api/users/${userId}/subscriptions`);
  if (!res.ok) {
    throw new Error(`Failed to fetch subscriptions for user ${userId}`);
  }
  return res.json();
}

export async function createPurchaseHistory(data: {
    user_id: string;
    purchase_date: string;
    amount: number;
    description: string;
    subscriptionPlan: string; // e.g., 'Basic', 'Premium', 'Unlimited'
    vehicle_id?: string; // Optional: if related vehicle data is available.
  }): Promise<PurchaseHistory> {
    const res = await fetch(`/api/purchase-history`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      throw new Error('Failed to create purchase history record');
    }
    return res.json();
  }
